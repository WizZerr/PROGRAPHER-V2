"""The comparison used in every validation run: colour and brightness at 48 px (ignores sharpening/geometry).
Delta E 1976: below ~2 hard to see, 2-5 visible side by side, above 5 clearly different."""
from __future__ import annotations

import numpy as np
from PIL import Image


def _lin(u8: np.ndarray) -> np.ndarray:
    v = u8.astype(np.float64) / 255.0
    return np.where(v <= 0.04045, v / 12.92, ((v + 0.055) / 1.055) ** 2.4)


def _lab(u8: np.ndarray) -> np.ndarray:
    m = np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]])
    xyz = _lin(u8) @ m.T / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], axis=-1)


def _small(u8: np.ndarray, size) -> np.ndarray:
    return np.asarray(Image.fromarray(np.ascontiguousarray(u8)).resize(size, Image.BILINEAR))


def compare(ours: np.ndarray, ref: np.ndarray) -> dict:
    """ours, ref: H x W x 3 uint8 sRGB. Both resized to 48 px on the long edge (90-degree turns tried).
    Returns deltaE48 (mean Delta E 1976), stops (mean luminance, log2 ours/ref), rg and bg (channel-ratio shift)."""
    best = None
    for k in (0, 1, 3, 2):
        o = np.rot90(ours, k)
        if (o.shape[0] > o.shape[1]) != (ref.shape[0] > ref.shape[1]) and k in (0, 2):
            continue
        size = (48, max(1, round(48 * ref.shape[0] / ref.shape[1]))) if ref.shape[1] >= ref.shape[0] else \
            (max(1, round(48 * ref.shape[1] / ref.shape[0])), 48)
        a, b = _small(o, size), _small(ref, size)
        de = float(np.sqrt(((_lab(a) - _lab(b)) ** 2).sum(-1)).mean())
        if best is None or de < best["deltaE48"]:
            la, lb = _lin(a).reshape(-1, 3).mean(0) + 1e-6, _lin(b).reshape(-1, 3).mean(0) + 1e-6
            y = np.array([0.2126, 0.7152, 0.0722])
            best = {"deltaE48": de, "stops": float(np.log2((la @ y) / (lb @ y))),
                    "rg": float(la[0] / la[1] - lb[0] / lb[1]), "bg": float(la[2] / la[1] - lb[2] / lb[1]),
                    "turned": k != 0}
    return best
