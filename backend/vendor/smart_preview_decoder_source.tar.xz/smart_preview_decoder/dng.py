"""Layer 1: a Lightroom Smart Preview DNG -> camera-native linear RGB, following the DNG 1.7 specification.

A Lightroom Classic Smart Preview is a DNG 1.7 file whose main image is LinearRaw (photometric 34892), compressed
with lossy JPEG XL (compression 52546), up to 2560 px on the long edge. Lightroom stores perceptually shaped
samples and puts the way back to linear light in the file itself: one cubic MapPolynomial per colour plane in
OpcodeList2. LightCraft (MIT/Apache, crates/raw/src/jxl.rs) documents the same reading. The polynomial must be
applied to the samples as stored (the decoder's declared encoding), never to a decoder-linearised image.

Validated against Lightroom's own Smart Preview export (see VALIDATION.md):
  Canon R6 II, 80 held-out wedding photos: Delta E 2.51 at 48 px, brightness -0.017 stops.
  7 cameras (Canon R6 II/R5, Sony A7 V/A1 II, Nikon Z6 III/D5300, Fuji X-T50): Delta E 0.94-4.11.
Read only. No file is written.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

MAX_PIXELS = 35_000_000  # Smart Previews are at most 2560 px long; anything far bigger is refused before decoding
PHOTOMETRIC_LINEAR_RAW = 34892
COMPRESSION_JPEG_XL = 52546

# DNG tags read here (the camera profile tags are read in profile.py)
ORIENTATION, BLACK_LEVEL, WHITE_LEVEL, LINEARIZATION_TABLE = 274, 50714, 50717, 50712
AS_SHOT_NEUTRAL, BASELINE_EXPOSURE = 50728, 50730
DEFAULT_CROP_ORIGIN, DEFAULT_CROP_SIZE, DEFAULT_USER_CROP = 50719, 50720, 51125
OPCODE_LIST_1, OPCODE_LIST_2, OPCODE_LIST_3 = 51008, 51009, 51022
UNIQUE_CAMERA_MODEL, PROFILE_NAME = 50708, 50936
PROFILE_TAGS = (50721, 50722, 50964, 50965, 50778, 50779, 50937, 50938, 50939, 50940, 50981, 50982,
                51107, 51108, 51109)
READ_TAGS = (ORIENTATION, BLACK_LEVEL, WHITE_LEVEL, LINEARIZATION_TABLE, AS_SHOT_NEUTRAL, BASELINE_EXPOSURE,
             DEFAULT_CROP_ORIGIN, DEFAULT_CROP_SIZE, DEFAULT_USER_CROP, OPCODE_LIST_1, OPCODE_LIST_2,
             OPCODE_LIST_3, UNIQUE_CAMERA_MODEL, PROFILE_NAME) + PROFILE_TAGS
# CameraCalibration1/2 and AnalogBalance are not read: in every Smart Preview checked they are diagonal / 1,1,1,
# and a diagonal calibration cancels out when the data is divided by AsShotNeutral.

OPCODE_NAMES = {1: "WarpRectilinear", 2: "WarpFisheye", 3: "FixVignetteRadial", 4: "FixBadPixelsConstant",
                5: "FixBadPixelsList", 6: "TrimBounds", 7: "MapTable", 8: "MapPolynomial", 9: "GainMap",
                10: "DeltaPerRow", 11: "DeltaPerColumn", 12: "ScalePerRow", 13: "ScalePerColumn",
                14: "WarpRectilinear2"}


class SmartPreviewError(Exception):
    """The file is not a Smart Preview this module can decode. The message never contains the file path."""


@dataclass
class SmartPreview:
    linear: np.ndarray          # H x W x 3 float32, camera-native linear, 1.0 = white level; cropped and upright
    as_shot_neutral: np.ndarray  # (3,) camera-native neutral of the as-shot white balance, G = 1
    baseline_exposure: float     # stops, BaselineExposure tag
    tags: dict = field(repr=False)  # raw tag values (int code -> value), for profile.py
    compression: int = 0
    opcodes_applied: list = field(default_factory=list)
    opcodes_ignored: list = field(default_factory=list)  # lists 1 and 3, and any stage-2 opcode not supported
    camera_model: str | None = None
    profile_name: str | None = None


# ---------------- tag helpers ----------------
def _vals(v) -> np.ndarray:
    return np.array(v, dtype=float).ravel()


def _rational(v, n: int) -> np.ndarray:
    """tifffile returns RATIONAL arrays as (num, den, num, den, ...); plain numbers stay as they are."""
    a = _vals(v)
    if a.size == 2 * n:
        return a[0::2] / np.where(a[1::2] == 0, 1, a[1::2])
    return a


def read_dng(path: str | Path) -> tuple[np.ndarray, dict, int]:
    """Main LinearRaw image (as stored), the tags used here, and its compression code."""
    import tifffile

    try:
        with tifffile.TiffFile(str(path)) as tif:
            pages = []
            for pg in tif.pages:
                pages.append(pg)
                pages.extend(getattr(pg, "pages", None) or [])
            linear = [pg for pg in pages if int(getattr(pg, "photometric", 0) or 0) == PHOTOMETRIC_LINEAR_RAW]
            if not linear:
                raise SmartPreviewError("no LinearRaw image (not a Lightroom Smart Preview)")
            main = max(linear, key=lambda pg: pg.shape[0] * pg.shape[1])
            if main.shape[0] * main.shape[1] > MAX_PIXELS:
                raise SmartPreviewError("image too large for a Smart Preview")
            tags = {}
            for code in READ_TAGS:
                for pg in [main] + pages:  # the main image's own tags first (crop, black/white, opcodes)
                    t = pg.tags.get(code)
                    if t is not None:
                        tags[code] = t.value
                        break
            arr = main.asarray()
            return arr, tags, int(main.compression)
    except SmartPreviewError:
        raise
    except Exception as exc:  # noqa: BLE001  (tifffile/imagecodecs errors may carry the path)
        raise SmartPreviewError(f"cannot read DNG: {type(exc).__name__}") from None


# ---------------- opcodes (DNG 1.7, section 6) ----------------
def parse_opcodes(blob) -> list[tuple[int, int, bytes]]:
    """Opcode list (always big-endian): count, then per opcode ID, DNG version, flags, byte count, parameters."""
    b = bytes(blob)
    n = struct.unpack(">I", b[:4])[0]
    i, ops = 4, []
    for _ in range(n):
        oid, _ver, flags, size = struct.unpack(">IIII", b[i:i + 16])
        ops.append((oid, flags, b[i + 16:i + 16 + size]))
        i += 16 + size
    return ops


def apply_opcodes(x: np.ndarray, blob) -> tuple[np.ndarray, list[str], list[str]]:
    """Apply stage-2 opcodes to x (H x W x 3, 0..1 after black/white scaling)."""
    applied, ignored = [], []
    h, w = x.shape[:2]
    for oid, flags, prm in parse_opcodes(blob):
        name = OPCODE_NAMES.get(oid, f"opcode{oid}")
        if oid in (7, 8, 9):
            top, left, bottom, right, plane, planes, rp, cp = struct.unpack(">8I", prm[:32])
            rs, cs = slice(top, min(bottom, h), max(rp, 1)), slice(left, min(right, w), max(cp, 1))
            pl = range(plane, min(plane + planes, x.shape[2]))
            if oid == 8:  # MapPolynomial: c0 + c1 v + c2 v^2 + ... (Lightroom: cubic, one per plane)
                deg = struct.unpack(">I", prm[32:36])[0]
                coef = struct.unpack(f">{deg + 1}d", prm[36:36 + 8 * (deg + 1)])
                for p in pl:
                    v = x[rs, cs, p]
                    x[rs, cs, p] = np.clip(sum(c * v ** k for k, c in enumerate(coef)), 0, 1)
            elif oid == 7:  # MapTable
                size = struct.unpack(">I", prm[32:36])[0]
                tab = np.array(struct.unpack(f">{size}H", prm[36:36 + 2 * size]), dtype=np.float64) / 65535.0
                for p in pl:
                    idx = np.clip(np.round(x[rs, cs, p] * 65535).astype(np.int64), 0, size - 1)
                    x[rs, cs, p] = tab[idx]
            else:  # GainMap, bilinear
                pv, ph = struct.unpack(">II", prm[32:40])
                sv, sh, ov, oh = struct.unpack(">4d", prm[40:72])
                mp = struct.unpack(">I", prm[72:76])[0]
                g = np.array(struct.unpack(f">{pv * ph * mp}f", prm[76:76 + 4 * pv * ph * mp])).reshape(pv, ph, mp)
                rows, cols = np.arange(h)[rs], np.arange(w)[cs]
                vv = np.clip(((rows - top) / max(bottom - top, 1) - ov) / max(sv, 1e-12), 0, pv - 1)
                hh = np.clip(((cols - left) / max(right - left, 1) - oh) / max(sh, 1e-12), 0, ph - 1)
                v0, h0 = np.floor(vv).astype(int), np.floor(hh).astype(int)
                v1, h1 = np.minimum(v0 + 1, pv - 1), np.minimum(h0 + 1, ph - 1)
                fv, fh = (vv - v0)[:, None], (hh - h0)[None, :]
                for p in pl:
                    gp = g[..., min(p - plane, mp - 1)]
                    gain = (gp[v0][:, h0] * (1 - fv) * (1 - fh) + gp[v0][:, h1] * (1 - fv) * fh +
                            gp[v1][:, h0] * fv * (1 - fh) + gp[v1][:, h1] * fv * fh)
                    x[rs, cs, p] = x[rs, cs, p] * gain
            applied.append(name)
        elif oid == 3:  # FixVignetteRadial
            k = struct.unpack(">7d", prm[:56])
            cy, cx = k[6] * (h - 1), k[5] * (w - 1)
            yy, xx = np.mgrid[0:h, 0:w]
            rmax = max(np.hypot(cx, cy), np.hypot(w - 1 - cx, cy), np.hypot(cx, h - 1 - cy),
                       np.hypot(w - 1 - cx, h - 1 - cy))
            r2 = ((xx - cx) ** 2 + (yy - cy) ** 2) / rmax ** 2
            x = x * (1 + k[0] * r2 + k[1] * r2 ** 2 + k[2] * r2 ** 3 + k[3] * r2 ** 4 + k[4] * r2 ** 5)[..., None]
            applied.append(name)
        else:
            ignored.append(name + (" (optional)" if flags & 1 else ""))
    return x, applied, ignored


# ---------------- geometry ----------------
def default_crop(x: np.ndarray, tags: dict) -> np.ndarray:
    """DefaultCropOrigin/Size (pixels, x then y), then DefaultUserCrop (fractions top, left, bottom, right).
    Lightroom shows this framing; e.g. a Fuji shot in 5:4 is stored as a 3:2 image plus DefaultUserCrop."""
    h, w = x.shape[:2]
    if tags.get(DEFAULT_CROP_ORIGIN) is not None and tags.get(DEFAULT_CROP_SIZE) is not None:
        ox, oy = _rational(tags[DEFAULT_CROP_ORIGIN], 2)[:2]
        cw, ch = _rational(tags[DEFAULT_CROP_SIZE], 2)[:2]
        y0, x0 = int(round(oy)), int(round(ox))
        x = x[max(0, y0):min(h, y0 + int(round(ch))), max(0, x0):min(w, x0 + int(round(cw)))]
    if tags.get(DEFAULT_USER_CROP) is not None:
        t, l, b, r = _rational(tags[DEFAULT_USER_CROP], 4)[:4]
        h, w = x.shape[:2]
        if 0 <= t < b <= 1 and 0 <= l < r <= 1:
            x = x[int(round(t * h)):int(round(b * h)), int(round(l * w)):int(round(r * w))]
    return x


def upright(x: np.ndarray, orientation: int) -> np.ndarray:
    """TIFF Orientation 1/3/6/8 (the only ones cameras write)."""
    return {3: np.rot90(x, 2), 6: np.rot90(x, -1), 8: np.rot90(x, 1)}.get(orientation, x)


def _resize(x: np.ndarray, long_edge: int | None) -> np.ndarray:
    if not long_edge:
        return x
    from PIL import Image

    h, w = x.shape[:2]
    s = long_edge / max(h, w)
    if s >= 1:
        return x
    size = (round(w * s), round(h * s))
    return np.stack([np.asarray(Image.fromarray(x[..., c].astype(np.float32)).resize(size, Image.BILINEAR))
                     for c in range(3)], axis=-1)


# ---------------- public ----------------
def decode_smart_preview(path: str | Path, long_edge: int | None = 1024) -> SmartPreview:
    """Smart Preview DNG -> SmartPreview (camera-native linear RGB + what is needed to render it).

    long_edge: downscale for speed (the validation used 1024); None keeps the stored size (up to 2560)."""
    arr, tags, compression = read_dng(path)
    maxv = float(np.iinfo(arr.dtype).max) if np.issubdtype(arr.dtype, np.integer) else 1.0
    x = arr.astype(np.float64)
    if x.ndim == 2:
        x = np.repeat(x[..., None], 3, axis=2)
    if x.shape[2] < 3:
        raise SmartPreviewError("fewer than 3 colour planes")
    x = x[..., :3]
    if tags.get(LINEARIZATION_TABLE) is not None:  # none of Lightroom's Smart Previews seen so far has one
        t = _vals(tags[LINEARIZATION_TABLE])
        x = t[np.clip(x.astype(np.int64), 0, t.size - 1)]
    white = np.resize(_vals(tags[WHITE_LEVEL]) if tags.get(WHITE_LEVEL) is not None else np.array([maxv]), 3)
    black = np.zeros(3)
    if tags.get(BLACK_LEVEL) is not None:  # e.g. Nikon Z6 III Smart Previews carry a per-plane black level
        b = _vals(tags[BLACK_LEVEL])
        black = np.resize(_rational(tags[BLACK_LEVEL], 3) if b.size in (2, 6) else b, 3)
    x = np.clip((x - black) / np.maximum(white - black, 1e-9), 0, 1)
    applied, ignored = [], []
    if tags.get(OPCODE_LIST_2) is not None:
        x, applied, ignored = apply_opcodes(x, tags[OPCODE_LIST_2])
    for code in (OPCODE_LIST_1, OPCODE_LIST_3):  # list 1 = before linearisation (raw CFA), 3 = geometry
        if tags.get(code) is not None:
            ignored += [OPCODE_NAMES.get(o, f"opcode{o}") for o, _f, _p in parse_opcodes(tags[code])]
    x = default_crop(x, tags)
    x = upright(x, int(_vals(tags.get(ORIENTATION) or [1])[0]))
    x = _resize(np.ascontiguousarray(x), long_edge)

    neutral = _rational(tags[AS_SHOT_NEUTRAL], 3) if tags.get(AS_SHOT_NEUTRAL) is not None else np.ones(3)
    neutral = neutral / neutral[1]
    be = float(_rational(tags[BASELINE_EXPOSURE], 1)[0]) if tags.get(BASELINE_EXPOSURE) is not None else 0.0
    return SmartPreview(linear=np.ascontiguousarray(x, dtype=np.float32), as_shot_neutral=neutral,
                        baseline_exposure=be, tags=tags, compression=compression, opcodes_applied=applied,
                        opcodes_ignored=ignored, camera_model=str(tags.get(UNIQUE_CAMERA_MODEL) or "") or None,
                        profile_name=str(tags.get(PROFILE_NAME) or "") or None)
