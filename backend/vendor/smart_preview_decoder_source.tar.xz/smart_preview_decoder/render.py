"""Layer 3: render a decoded Smart Preview to an 8-bit sRGB image that matches Lightroom's Reset rendering
(Adobe Color profile, As Shot white balance, Process Version defaults).

Pipeline (the one validated against Lightroom, see VALIDATION.md):
  camera linear / AsShotNeutral -> [lens vignetting gain] -> ForwardMatrix -> ProPhoto -> HueSatMap
  -> Adobe Color look table (replaces the profile's own LookTable) -> sRGB primaries
  -> x 2^(BaselineExposure + profile offset + CALIBRATION_STOPS) -> learned tone curve -> sRGB 8-bit
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .dng import SmartPreview
from .profile import PROPHOTO_TO_SRGB, EmbeddedProfile, apply_hsv_table

# Exposure correction found by measurement, cause not yet known. Fitted on 20 Canon R6 II photos, tested on 80
# others (-0.017 stops left) and on 7 cameras (every camera within +-0.05 stops). See VALIDATION.md.
CALIBRATION_STOPS = -0.144
DEFAULT_TONE_CURVE = Path(__file__).with_name("data") / "tone_curve.json"


def load_tone_curve(path: str | Path = DEFAULT_TONE_CURVE) -> dict:
    """Learned 1-D tone curve (log2 linear -> display 0..1), same for R, G, B. Learned on the Canon R6 II pilot
    (RAW vs Lightroom Reset export); look_mode 'replace' = the look table replaces the profile's LookTable."""
    tc = json.loads(Path(path).read_text(encoding="utf-8"))
    return {"x": np.array(tc["log2_linear"], dtype=float), "y": np.array(tc["output"], dtype=float),
            "look_mode": tc.get("look_mode") or "replace", "look_srgb": bool(tc.get("look_srgb", False))}


def apply_tone_curve(lin: np.ndarray, curve: dict) -> np.ndarray:
    lx = np.log2(np.maximum(lin, 2 ** -14))
    return (np.clip(np.interp(lx, curve["x"], curve["y"]), 0, 1) * 255 + 0.5).astype(np.uint8)


def render_srgb(sp: SmartPreview, look: tuple | None = None, curve: dict | None = None,
                vignette_gain: np.ndarray | None = None, exposure_offset: float = CALIBRATION_STOPS) -> np.ndarray:
    """SmartPreview -> H x W x 3 uint8 sRGB, as Lightroom renders the photo with Reset settings.

    look: read_look_table('Adobe Color.xmp'). None = use the profile's own LookTable (not validated, see README).
    curve: load_tone_curve(); None = the packaged one.
    vignette_gain: H x W (any size, resized) lens light-falloff gain, see lens.py. Lightroom applies the lens
      profile by default; the Smart Preview itself is NOT lens-corrected, so pass it when the photo has
      'Enable Profile Corrections' on.
    exposure_offset: CALIBRATION_STOPS by default; 0 = the uncorrected DNG rendering."""
    curve = curve or load_tone_curve()
    prof = EmbeddedProfile(sp.tags)
    neutral = sp.as_shot_neutral
    w = prof.weight(neutral)
    x = np.clip(sp.linear.astype(np.float64) / neutral, 0, 1)
    if vignette_gain is not None:
        if vignette_gain.shape != x.shape[:2]:
            from PIL import Image

            vignette_gain = np.asarray(Image.fromarray(vignette_gain.astype(np.float32)).resize((x.shape[1], x.shape[0])))
        x = x * vignette_gain[..., None]
    pp = np.clip(x @ prof.camera_to_prophoto(w).T, 0, None)
    hsm = prof.hue_sat_map(w)
    if hsm is not None and prof.hsm_dims is not None:
        pp = apply_hsv_table(pp, prof.hsm_dims, hsm, prof.hsm_srgb)
    if prof.lut is not None and prof.lut_dims is not None and not (look is not None and curve["look_mode"] == "replace"):
        pp = apply_hsv_table(pp, prof.lut_dims, prof.lut, prof.lut_srgb)
    if look is not None:
        pp = apply_hsv_table(pp, look[0], look[1], curve["look_srgb"])
    lin = np.clip(pp @ PROPHOTO_TO_SRGB.T, 0, None) * 2.0 ** (sp.baseline_exposure + prof.exp_offset + exposure_offset)
    return apply_tone_curve(lin, curve)
