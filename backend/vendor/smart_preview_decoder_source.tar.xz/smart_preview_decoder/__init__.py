"""Decode Lightroom Classic Smart Previews (DNG 1.7, LinearRaw, JPEG XL) and render them like Lightroom.

    from smart_preview_decoder import decode_smart_preview, render_srgb, read_look_table
    sp = decode_smart_preview("<uuid>.dng")                  # layer 1: camera-native linear RGB + metadata
    img = render_srgb(sp, look=read_look_table("Adobe Color.xmp"))   # layers 2-3: uint8 sRGB, Lightroom Reset look

See README.md (integration) and VALIDATION.md (what was measured against Lightroom).
"""
from .dng import COMPRESSION_JPEG_XL, SmartPreview, SmartPreviewError, decode_smart_preview
from .metrics import compare
from .profile import EmbeddedProfile, read_look_table
from .render import CALIBRATION_STOPS, load_tone_curve, render_srgb

__all__ = ["COMPRESSION_JPEG_XL", "CALIBRATION_STOPS", "EmbeddedProfile", "SmartPreview", "SmartPreviewError",
           "compare", "decode_smart_preview", "load_tone_curve", "read_look_table", "render_srgb"]
__version__ = "1.0.0"
