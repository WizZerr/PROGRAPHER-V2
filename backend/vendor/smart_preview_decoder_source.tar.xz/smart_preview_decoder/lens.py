"""Lens light-falloff (vignetting) gain from Adobe's .lcp lens profiles, which ship with every Lightroom install
(Windows: C:\\ProgramData\\Adobe\\CameraRaw\\LensProfiles\\1.0). Lightroom applies the lens profile by default and
the Smart Preview is stored WITHOUT that correction, so the renderer has to apply it.

Validated only together with the rest of the pipeline on the Canon R6 II pilot (lens corrections on in Lightroom).
The 7-camera test ran with lens corrections off on both sides, so this file was not part of it.
Distortion and chromatic aberration are not handled (they move pixels; they barely change colour statistics).
"""
from __future__ import annotations

import math
import re
from pathlib import Path

import numpy as np

NS = {"rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
      "st": "http://ns.adobe.com/photoshop/1.0/camera-profile",
      "ps": "http://ns.adobe.com/photoshop/1.0/"}


def norm(s: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _attrs(el):
    """stCamera attributes of an element, whether written inline or on a child rdf:Description."""
    a = {k.split("}")[-1]: v for k, v in el.attrib.items()}
    d = el.find("rdf:Description", NS)
    if d is not None:
        a.update({k.split("}")[-1]: v for k, v in d.attrib.items()})
    return a, (d if d is not None else el)


def read_lcp(path: str | Path) -> tuple[str | None, list[dict]]:
    import xml.etree.ElementTree as ET

    root = ET.parse(path).getroot()
    entries, lens = [], None
    for li in root.findall(".//ps:CameraProfiles/rdf:Seq/rdf:li", NS):
        top, body = _attrs(li)
        lens = lens or top.get("Lens")
        persp = body.find("st:PerspectiveModel", NS)
        if persp is None:
            continue
        pa, pbody = _attrs(persp)
        vig = pbody.find("st:VignetteModel", NS)
        if vig is None:
            continue
        va, vbody = _attrs(vig)
        pts = [tuple(float(x) for x in li2.text.split(",")) for li2 in
               vbody.findall("st:VignetteModelPiecewiseParam/rdf:Seq/rdf:li", NS) if li2.text and "," in li2.text]
        try:
            entries.append({"focal": float(top["FocalLength"]), "av": float(top["ApertureValue"]),
                            "fx": float(va.get("FocalLengthX") or pa.get("FocalLengthX") or 1.0),
                            "p": [float(va.get(f"VignetteModelParam{k}", 0.0)) for k in (1, 2, 3)],
                            "pw": np.array(pts) if len(pts) >= 2 else None})
        except (KeyError, ValueError):
            continue
    return lens, entries


def lens_index(folder: str | Path) -> dict[str, list[dict]]:
    """normalised lens name -> profile entries, from the RAW .lcp files under folder."""
    idx = {}
    for p in Path(folder).rglob("*.lcp"):
        lens, entries = read_lcp(p)
        if lens and entries and "RAW" in p.name.upper():
            idx.setdefault(norm(lens), entries)
    return idx


def vignette_gain(entries: list[dict], focal: float, fnum: float, shape=(64, 96), k: int = 3) -> np.ndarray:
    """Light-falloff correction gain map (Adobe camera model): falloff(r), r = radius / max(W,H) / FocalLengthX.
    Uses the piecewise curve when the profile has one, otherwise the r^2/r^4/r^6 polynomial. shape = (h, w) of
    the upright image (only the aspect ratio matters; render_srgb resizes it)."""
    av = 2 * math.log2(fnum)
    d = np.array([abs(math.log(e["focal"] / focal)) * 4 + abs(e["av"] - av) for e in entries])
    near = np.argsort(d)[:k]
    w = 1 / (d[near] + 1e-3)
    w /= w.sum()
    h, wd = shape
    dmax = max(h, wd)
    yy, xx = np.mgrid[0:h, 0:wd]
    rad = np.sqrt(((xx + 0.5 - wd / 2) / dmax) ** 2 + ((yy + 0.5 - h / 2) / dmax) ** 2)
    fall = np.zeros_like(rad)
    for wi, i in zip(w, near):
        e = entries[i]
        r = rad / e["fx"]
        if e["pw"] is not None:
            f = np.interp(r, e["pw"][:, 0], e["pw"][:, 1])
        else:
            r2 = r ** 2
            f = 1 + e["p"][0] * r2 + e["p"][1] * r2 ** 2 + e["p"][2] * r2 ** 3
        fall += wi * f
    return 1 / np.clip(fall, 0.2, None)
