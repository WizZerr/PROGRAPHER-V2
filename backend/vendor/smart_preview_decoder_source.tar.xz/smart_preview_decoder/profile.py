"""Layer 2: colour. The camera profile Lightroom embeds in every Smart Preview (DNG profile tags), the DNG
reference HSV-table lookup, and Adobe's "Adobe Color" look table (read from Lightroom's own Adobe Color.xmp).

No per-camera Adobe file is needed: the Smart Preview carries its camera's ColorMatrix/ForwardMatrix/HueSatMap.
On the Canon R6 II pilot, rendering with this embedded profile gave the same numbers, to the last digit, as
rendering with Adobe's external "Adobe Standard" .dcp for that camera.
"""
from __future__ import annotations

import re
import struct
import zlib
from pathlib import Path

import numpy as np

from .dng import _rational, _vals

ILLUMINANT_K = {17: 2856.0, 21: 6504.0, 20: 5503.0, 23: 5003.0, 1: 5500.0, 2: 3800.0, 3: 2856.0, 4: 5500.0,
                10: 6504.0, 11: 7504.0, 12: 6430.0, 13: 5000.0, 14: 4150.0, 15: 3450.0, 18: 4874.0, 19: 6774.0,
                22: 7504.0, 24: 3200.0}
XYZD50_TO_PROPHOTO = np.array([[1.3459433, -0.2556075, -0.0511118],
                               [-0.5445989, 1.5081673, 0.0205351],
                               [0.0, 0.0, 1.2118128]])
XYZD50_TO_SRGB = np.array([[3.1338561, -1.6168667, -0.4906146],
                           [-0.9787684, 1.9161415, 0.0334540],
                           [0.0719453, -0.2289914, 1.4052427]])
PROPHOTO_TO_SRGB = XYZD50_TO_SRGB @ np.linalg.inv(XYZD50_TO_PROPHOTO)


class EmbeddedProfile:
    """DNG camera profile from a Smart Preview's tags (two calibration illuminants, forward matrices)."""

    def __init__(self, tags: dict):
        def r9(code):
            return _rational(tags[code], 9) if tags.get(code) is not None else None

        def arr(code):
            return _vals(tags[code]) if tags.get(code) is not None else None

        self.name = str(tags.get(50936) or "embedded")
        self.cm1, self.cm2, self.fm1, self.fm2 = r9(50721), r9(50722), r9(50964), r9(50965)
        if self.fm1 is None and self.fm2 is None:
            raise ValueError("profile has no ForwardMatrix")  # every Lightroom Smart Preview seen has both
        self.t1 = ILLUMINANT_K.get(int(_vals(tags.get(50778) or [17])[0]), 2856.0)
        self.t2 = ILLUMINANT_K.get(int(_vals(tags.get(50779) or [21])[0]), 6504.0)
        self.hsm_dims, self.hsm1, self.hsm2 = arr(50937), arr(50938), arr(50939)
        self.hsm_srgb = int(_vals(tags.get(51107) or [0])[0]) == 1
        self.lut_dims, self.lut = arr(50981), arr(50982)
        self.lut_srgb = int(_vals(tags.get(51108) or [0])[0]) == 1
        self.exp_offset = float(_rational(tags[51109], 1)[0]) if tags.get(51109) is not None else 0.0

    def weight(self, neutral: np.ndarray) -> float:
        """Interpolation weight for illuminant 1 from the as-shot neutral (iterative, DNG spec style)."""
        if self.cm1 is None or self.cm2 is None:
            return 0.0 if self.cm1 is None else 1.0
        cm1, cm2 = self.cm1.reshape(3, 3), self.cm2.reshape(3, 3)
        w = 0.5
        for _ in range(10):
            xyz = np.linalg.solve(w * cm1 + (1 - w) * cm2, neutral)
            x, y = xyz[0] / xyz.sum(), xyz[1] / xyz.sum()
            nn = (x - 0.3320) / (0.1858 - y)
            cct = 449 * nn ** 3 + 3525 * nn ** 2 + 6823.3 * nn + 5520.33
            w = float(np.clip((1 / cct - 1 / self.t2) / (1 / self.t1 - 1 / self.t2), 0, 1))
        return w

    def camera_to_prophoto(self, w: float) -> np.ndarray:
        """White-balanced camera RGB (neutral already divided out) -> linear ProPhoto RGB."""
        fm = self.fm1 if self.fm2 is None else (self.fm2 if self.fm1 is None else w * self.fm1 + (1 - w) * self.fm2)
        return XYZD50_TO_PROPHOTO @ fm.reshape(3, 3)

    def hue_sat_map(self, w: float) -> np.ndarray | None:
        if self.hsm1 is None:
            return None
        return self.hsm1 if self.hsm2 is None else w * self.hsm1 + (1 - w) * self.hsm2


def apply_hsv_table(rgb: np.ndarray, dims, table: np.ndarray, srgb_encoded_value: bool) -> np.ndarray:
    """DNG reference HueSatMap / LookTable lookup (trilinear in hue, saturation, value)."""
    H, S, V = (int(d) for d in dims)
    tab = table.reshape(V, H, S, 3)
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx, mn = rgb.max(axis=-1), rgb.min(axis=-1)
    v = mx
    delta = mx - mn
    s = np.where(mx > 0, delta / np.maximum(mx, 1e-12), 0)
    with np.errstate(invalid="ignore", divide="ignore"):
        h = np.where(delta == 0, 0,
                     np.where(mx == r, ((g - b) / delta) % 6, np.where(mx == g, (b - r) / delta + 2, (r - g) / delta + 4)))
    h = np.nan_to_num(h)
    hs = h * (H / 6.0)
    h0 = np.floor(hs).astype(int) % H
    hf = hs - np.floor(hs)
    h1 = (h0 + 1) % H
    ss = s * (S - 1)
    s0 = np.clip(np.floor(ss).astype(int), 0, max(S - 2, 0))
    sf = ss - s0 if S > 1 else np.zeros_like(ss)
    s1 = np.minimum(s0 + 1, S - 1)
    if V > 1:
        vv = np.clip(v, 0, 1)
        if srgb_encoded_value:
            vv = np.where(vv <= 0.0031308, 12.92 * vv, 1.055 * vv ** (1 / 2.4) - 0.055)
        vs = vv * (V - 1)
        v0 = np.clip(np.floor(vs).astype(int), 0, V - 2)
        vf = vs - v0
        v1 = v0 + 1
    else:
        v0 = v1 = np.zeros_like(h0)
        vf = np.zeros_like(hf)

    def lerp_s(vi, hi):
        return tab[vi, hi, s0] * (1 - sf)[..., None] + tab[vi, hi, s1] * sf[..., None]

    def lerp_h(vi):
        return lerp_s(vi, h0) * (1 - hf)[..., None] + lerp_s(vi, h1) * hf[..., None]

    m = lerp_h(v0) * (1 - vf)[..., None] + lerp_h(v1) * vf[..., None]
    h = (h + m[..., 0] * (6.0 / 360.0)) % 6
    s = np.clip(s * m[..., 1], 0, 1)
    v = v * m[..., 2]
    i = np.floor(h).astype(int) % 6
    f = h - np.floor(h)
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    return np.stack([np.choose(i, [v, q, p, p, t, v]), np.choose(i, [t, v, v, q, p, p]),
                     np.choose(i, [p, p, t, v, v, q])], axis=-1)


B85 = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-:+=^!/*?`'|()[]{}@%$#"


def read_look_table(xmp_path: str | Path) -> tuple[tuple[int, int, int], np.ndarray]:
    """The look table inside an Adobe profile .xmp such as Lightroom's 'Adobe Color.xmp'
    (crs:Table_<id>: Adobe base85, then zlib). Returns ((hue, sat, val divisions), flat float table)."""
    s = Path(xmp_path).read_text(encoding="utf-8", errors="replace")
    m = re.search(r'crs:Table_[0-9A-F]+="([^"]*)"', s)
    if not m:
        raise ValueError("no crs:Table_ in the look file")
    t = (m.group(1).replace("&quot;", '"').replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
         .replace("&#xA;", "").replace("\n", "").replace("\r", ""))
    idx = {c: i for i, c in enumerate(B85)}
    out = bytearray()
    for i in range(0, len(t), 5):
        ch = t[i:i + 5]
        v = sum(idx[c] * 85 ** k for k, c in enumerate(ch))
        out += struct.pack("<I", v & 0xFFFFFFFF)[: (4 if len(ch) == 5 else len(ch) - 1)]
    raw = zlib.decompress(bytes(out[4:]))
    _, _, h, sdiv, vdiv = struct.unpack("<5I", raw[:20])
    n = h * sdiv * vdiv * 3
    return (h, sdiv, vdiv), np.frombuffer(raw[20:20 + 4 * n], dtype="<f4").astype(np.float64)
